require 'test_helper'

class LecturersHelperTest < ActionView::TestCase
end
