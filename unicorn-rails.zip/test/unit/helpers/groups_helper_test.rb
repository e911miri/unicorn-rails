require 'test_helper'

class GroupsHelperTest < ActionView::TestCase
end
