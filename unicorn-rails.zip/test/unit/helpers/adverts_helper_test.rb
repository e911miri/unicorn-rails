require 'test_helper'

class AdvertsHelperTest < ActionView::TestCase
end
