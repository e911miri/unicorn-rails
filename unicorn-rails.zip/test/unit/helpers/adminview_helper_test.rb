require 'test_helper'

class AdminviewHelperTest < ActionView::TestCase
end
