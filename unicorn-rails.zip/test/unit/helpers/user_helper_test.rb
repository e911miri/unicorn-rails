require 'test_helper'

class UserHelperTest < ActionView::TestCase
end
