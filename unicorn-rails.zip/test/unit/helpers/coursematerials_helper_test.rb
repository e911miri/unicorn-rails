require 'test_helper'

class CoursematerialsHelperTest < ActionView::TestCase
end
