require 'test_helper'

class AccomodationsHelperTest < ActionView::TestCase
end
