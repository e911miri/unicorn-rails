require 'test_helper'

class UserProfilesHelperTest < ActionView::TestCase
end
