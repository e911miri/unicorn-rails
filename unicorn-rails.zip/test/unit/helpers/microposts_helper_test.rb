require 'test_helper'

class MicropostsHelperTest < ActionView::TestCase
end
