require 'test_helper'

class LectureschedulesHelperTest < ActionView::TestCase
end
