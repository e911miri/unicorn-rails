require 'test_helper'

class StudentviewHelperTest < ActionView::TestCase
end
