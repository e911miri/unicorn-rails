require 'test_helper'

class CoursematerialTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
