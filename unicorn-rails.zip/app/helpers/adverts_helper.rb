module AdvertsHelper
end
