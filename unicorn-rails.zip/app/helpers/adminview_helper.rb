module AdminviewHelper
end
