class StudentController < ApplicationController
  def index
  end
end
