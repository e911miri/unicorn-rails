class News < ActiveRecord::Base
  attr_accessible :content, :notes, :source
end
